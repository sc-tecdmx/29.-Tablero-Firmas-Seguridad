package mx.gob.tecdmx.tablerofirmas.api.restablecer.contraseña;

public class DTOResponseRessetPass {
	String status;
	String message;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
