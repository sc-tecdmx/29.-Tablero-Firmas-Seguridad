package mx.gob.tecdmx.tablerofirmas.api.uadscripcionareas;

public class PayloadTipoDocByArea {
	String tipoDocumento;
	String codigoArea;
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getCodigoArea() {
		return codigoArea;
	}
	public void setCodigoArea(String codigoArea) {
		this.codigoArea = codigoArea;
	}
	
	
}
