package mx.gob.tecdmx.tablerofirmas.utils;

public class DTORol {

}
